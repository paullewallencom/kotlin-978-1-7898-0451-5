class CarDemo(make: String, model: String) {
    val make = make
    val model = model
}