fun main(args: Array<String>) {

    val a = 12
    val b = 25

    //  + - / *
    println(b + a)
    println(b - a)
    println(b / a)
    println(a * b)

    println(b % a)
}