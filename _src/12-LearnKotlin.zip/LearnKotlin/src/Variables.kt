fun main(args: Array<String>) {

    val name: String = "JonnyB"

    var isAwesome = true
    isAwesome = false

    println("Is " + name + " awesome? The answer is : " + isAwesome)

    var a: Int = 3
    var b = 6
    println(a + b)

    val doubleNum: Double = 123.45 //64 bit number
    val floatNum: Float = 123.45f // 32 bit

    val longNum: Long = 1237819283712L // 64 bit

    val aDouble = a.toString()

    var hero: String
    hero = "batman"
    hero = "superman"
    println(hero)



}